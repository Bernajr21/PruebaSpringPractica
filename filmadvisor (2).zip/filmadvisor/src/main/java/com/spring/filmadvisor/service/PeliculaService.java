package com.spring.filmadvisor.service;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Service;

import com.spring.filmadvisor.dao.PeliculaDao;

@Service
public class PeliculaService {
	PeliculaDao filmDao; 
	FilmQueryService queryService;

	
	public Collection<String> findAllGenres(ArrayList<String> list) {
		
		Collection<String> collection = new ArrayList<String>();
		
		
		return collection;
		
	};
}
