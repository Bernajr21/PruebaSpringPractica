package com.spring.filmadvisor.controladores;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.spring.filmadvisor.dao.PeliculaDaoImpl;
import com.spring.filmadvisor.modelo.Pelicula;
import com.spring.filmadvisor.upload.storage.StorageService;

@Controller
public class PeliculaController {

	@Autowired
	public PeliculaDaoImpl pelimpl;

	@Autowired
	private StorageService storageService;

	@GetMapping({ "/" })
	public String index(Model model) {
		model.addAttribute("listaTodas", pelimpl.findAll());
		return "index";
	}

	@GetMapping("/peliculaList")
	public String peli(Model model) {
		model.addAttribute("listaPeliculas", pelimpl.mostrarTitulos());
		return "pelicula";
	}

	@GetMapping("/generoList")
	public String gen(Model model) {
		model.addAttribute("listaGen", pelimpl.mostrarGeneros());
		return "genero";
	}

	@GetMapping({ "/buscarPeli" })
	public String buscarPeli(Model model) {
		model.addAttribute("buscarPeli2", new String());
		return "buscadorpeli";
	}

	@PostMapping({ "listado/enviar" })
	public String listaPeli(@RequestParam(value = "buscarPeli") String busqueda, Model model) {
		model.addAttribute("buscarPeli", pelimpl.buscarTitle(busqueda));
		return "buscadorpeli";
	}

	@GetMapping({ "/buscarGen" })
	public String buscarGen(Model model) {
		model.addAttribute("buscarGen2", new String());
		return "buscadorgen";
	}

	@PostMapping({ "listado/enviarGen" })
	public String listaGen(@RequestParam(value = "buscarGen") String busqueda, Model model) {
		model.addAttribute("buscarGen", pelimpl.buscarGenero(busqueda));
		return "buscadorgen";
	}

	@GetMapping({ "/buscarFecha" })
	public String buscarFecha2(Model model) {
		model.addAttribute("buscarGen2", new String());
		return "buscadorfecha";
	}

	@PostMapping({ "listado/enviarFecha" })
	public String buscarFecha(@RequestParam(value = "buscarFecha") String busqueda, Model model) {
		model.addAttribute("buscarFecha", pelimpl.buscarAños(busqueda));
		return "buscadorfecha";
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().body(file);
	}

	@GetMapping({ "/add" })
	public String add(Model model) {
		model.addAttribute("peliculaForm", new Pelicula());
		return "add";
	}

	@GetMapping("/pelicula/new")
	public String nuevoEmpleadoForm(Model model) {
		model.addAttribute("peliculaForm", new Pelicula());
		return "form";
	}

	@PostMapping("/pelicula/new/submit")
	public String nuevoEmpleadoSubmit(@Valid @ModelAttribute("peliculaForm") Pelicula nuevoPelicula,
			BindingResult bindingResult, @RequestParam("file") MultipartFile file) {

		if (bindingResult.hasErrors()) {
			return "form";

		} else {
			if (!file.isEmpty()) {
				String avatar = storageService.store(file, nuevoPelicula.getId());
				nuevoPelicula.setImg(MvcUriComponentsBuilder
						.fromMethodName(PeliculaController.class, "serveFile", avatar).build().toUriString());
			}
			
			pelimpl.add(nuevoPelicula);
			//pelimpl.add(nuevoPelicula);
			return "redirect:/empleado/list";
		}
	}
}
