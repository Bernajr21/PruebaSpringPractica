package com.spring.filmadvisor.dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.spring.filmadvisor.modelo.Pelicula;
@Component
public class UtilFilmFileReader {
	
	public List<Pelicula> listaPeliculas = new ArrayList<Pelicula>();
	
	@Value("${file.path}")
	public String file;
	
	@Value("${file.csv.separator}")
	public String separator;	
	
	@Value("${file.csv.list_separator}")
	public String listSeparator;
	
	public List<Pelicula> readFile(){
		List<Pelicula> list = new ArrayList<>();
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(new FileReader(ResourceUtils.getURL("classpath:").getPath()+file));
			String line = br.readLine();
			line = br.readLine();
			while (null!=line) {
				
				String[] fields = line.split(separator);
				
				List<String> lista_String = new ArrayList<>();
		
				for(String s: fields[3].split(listSeparator)) {
					lista_String.add(s);
				}
				
				
				list.add(new Pelicula(Long.parseLong(fields[0]),fields[1],fields[2],lista_String));
				line = br.readLine();
				
			}
		} catch(Exception e) {
			 e.printStackTrace();
		}	return list;
		
	}
	
	@PostConstruct
	public void init() {
		listaPeliculas = readFile();
	}

	public List<Pelicula> getListaPeliculas() {
		return listaPeliculas;
	}

	public void setListaPeliculas(List<Pelicula> listaPeliculas) {
		this.listaPeliculas = listaPeliculas;
	}
	
}
