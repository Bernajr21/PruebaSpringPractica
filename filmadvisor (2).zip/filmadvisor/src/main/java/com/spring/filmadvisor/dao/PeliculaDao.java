package com.spring.filmadvisor.dao;

import java.util.Collection;

import com.spring.filmadvisor.modelo.Pelicula;

public interface PeliculaDao {
	public Pelicula findById(long id);
	public Collection<Pelicula> findAll();
	public void insert(Pelicula film);
	public void edit(Pelicula film);
	public void delete(long id);
}
