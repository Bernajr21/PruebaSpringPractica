package com.spring.filmadvisor.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.filmadvisor.modelo.Pelicula;

@Service
public class PeliculaDaoImpl {
	@Autowired
	public UtilFilmFileReader utilFilm;
	
	public List<Pelicula> peliculas = new ArrayList<>();


	public Collection<Pelicula> findAll(){
		return utilFilm.getListaPeliculas();
	}
	
	public Collection<String> mostrarGeneros(){
		List<Pelicula> al = utilFilm.getListaPeliculas();
		Collection<String> stringList = new ArrayList<>();
		
		for (Pelicula s : al) {
			for (String string : s.getGenres()) {
				if(!stringList.contains(string)) {
					stringList.add(string);
				}
			}
			
		}
		return stringList;
	}
	
	public Collection<String> mostrarTitulos(){
		List<Pelicula> al = utilFilm.getListaPeliculas();
		Collection<String> stringList = new ArrayList<>();
		
		for (Pelicula s : al) {
			stringList.add(s.getTitle());
		}
		return stringList;
	}
	
	public Collection<String> buscarAños(String year){
		List<Pelicula> al = utilFilm.getListaPeliculas();
		Collection<String> stringList = new ArrayList<>();
		
		for (Pelicula s : al) {
			if(s.getYear().contains(year))
			stringList.add(s.getTitle());
		}
		return stringList;
	}
	
	public Collection<String> buscarTitle(String title){
		List<Pelicula> al = utilFilm.getListaPeliculas();
		Collection<String> stringList = new ArrayList<>();
		
		for (Pelicula s : al) {
			if(s.getTitle().contains(title))
			stringList.add(s.getTitle());
		}
		return stringList;
	} 
	
	public Collection<String> buscarGenero(String gene){
		List<Pelicula> al = utilFilm.getListaPeliculas();
		Collection<String> stringList = new ArrayList<>();
		
		for (Pelicula s : al) {
			if(s.getGenres().contains(gene))
			stringList.add(s.getTitle());
		}
		return stringList;
	} 
	
	public void add(Pelicula peli) {
		peli = new Pelicula();
	}
	
	public void delete(long id) {
		
	}
}
